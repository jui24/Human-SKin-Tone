from django.apps import AppConfig


class VerzeoConfig(AppConfig):
    name = 'verzeo'
